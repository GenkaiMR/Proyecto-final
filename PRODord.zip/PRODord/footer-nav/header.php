<header >
        <div class="header-container">
        <div class="logo-con">
        <div class="log">
        <img src="../imagenes/logo.png" alt="">
        </div>
        </div>
        <div class="con-exit">
        <a href="../conexion/logout.php" class="out-button ">
          <div class="icon-cont">
          <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-logout" width="32" height="32" viewBox="0 0 24 24" stroke-width="1.5" stroke="#ffffff" fill="none" stroke-linecap="round" stroke-linejoin="round">
  <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
  <path d="M14 8v-2a2 2 0 0 0 -2 -2h-7a2 2 0 0 0 -2 2v12a2 2 0 0 0 2 2h7a2 2 0 0 0 2 -2v-2" />
  <path d="M9 12h12l-3 -3" />
  <path d="M18 15l3 -3" />
</svg>
          </div>
       Log Out
        </a>
        </div>
        </div>
    </header>