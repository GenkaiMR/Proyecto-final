<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/ordenesAdmin.css">
    <title> Create Production Order</title>
    <link rel="icon" href="../imagenes/icono.png" type="imagen/png">
</head>
<body>
    <?php 

session_start();
    include '../footer-nav/header.php';
    include '../footer-nav/navAdmin.php';
    ?>
    <section  class="main-section">
                <div class="contenido">
                        <h1>CREATE ORDER</h1>
                    


                        
                </div>
    </section>
    
    <div class="footer-container">
    <?php include '../footer-nav/footer.php'; ?>   
    </div>

</body>
</html>